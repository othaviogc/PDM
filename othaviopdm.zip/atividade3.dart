import 'dart:io';
void main() {
 print('Digite a nota:');
  var n1 = double.parse(stdin.readLineSync()!);
  print('Digite a segunda nota:');
  var n2 = double.parse(stdin.readLineSync()!);
  print('Digite a terceira nota:');
  var n3 = double.parse(stdin.readLineSync()!);
  
  // Calcular a média ponderada com os pesos de 2, 3 e 5 para cada nota
  var media = (n1 * 2 + n2 * 3 + n3 * 5) / 10;
  
  // Imprimir a média final para o usuário
  print('A média final do aluno é: $media');
}