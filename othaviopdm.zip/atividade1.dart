import 'dart:io';
import 'dart:math';

void main() {
  print('escreva um valor:');
  int x = int.parse(stdin.readLineSync()!);

  print('escreva um valor:');
  int y = int.parse(stdin.readLineSync()!);

  print('escreva um valor:');
  int z = int.parse(stdin.readLineSync()!);

  print('escreva um valor:');
  int a = int.parse(stdin.readLineSync()!);

  // cálculo da distância entre os pontos
  double D = sqrt((y - x) * (y - x) + (a - z) * (a - z));

  print(D);
}