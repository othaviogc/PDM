import 'dart:io';
void main() {
print('Escreva um valor:');
  var x = double.parse(stdin.readLineSync()!);
  print('Escreva um segundo valor:');
  var y = double.parse(stdin.readLineSync()!);
  print('Escreva um terceiro valor:');
  var z = double.parse(stdin.readLineSync()!);
  // Calcular a expressão

  var r = (x+y)*(x+y);
   var s= (y+z)*(y+z);
  var d= (r+s)/2;
    print('Resultado: $d');
}