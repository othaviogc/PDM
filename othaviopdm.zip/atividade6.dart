import 'dart:io';
void main() {
  int ts = 0;
  int s = 0;
  int min = 0;
  int hs = 0;
  print("Digite o tempo em segundos: ");
  ts = int.parse(stdin.readLineSync()!);
  
  hs = ts ~/ 3600;
  min = (ts % 3600) ~/ 60;
  s = (ts % 3600) % 60;
  print("O tempo de duração é: $hs hora(s), $min minuto(s) e $s segundo(s)");
  
}