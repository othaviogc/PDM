import 'dart:io';
void main(){
  double cf;
  double cd;
  double ci;
  double cc; 
  print("Digite o preço de custo: ");
  cf = double.parse(stdin.readLineSync()!);
  cd = cf * (28/100);
  ci = cf * (45/100);
  cc = cf + cd + ci;
  
  print("Preço final do carro: \$$cc");
}